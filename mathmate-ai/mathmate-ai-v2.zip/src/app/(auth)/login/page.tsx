'use client'
import { useState }     from 'react'
import Link              from 'next/link'
import Image             from 'next/image'
import { useRouter }    from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Eye, EyeOff, Mail, Lock } from 'lucide-react'

export default function LoginPage() {
  const router   = useRouter()
  const supabase = createClient()
  const [form,    setForm]    = useState({ email: '', password: '' })
  const [showPw,  setShowPw]  = useState(false)
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')

  const handleLogin = async () => {
    setLoading(true); setError('')
    const { error: err } = await supabase.auth.signInWithPassword({ email: form.email, password: form.password })
    if (err) { setError(err.message); setLoading(false); return }
    router.push('/dashboard')
  }

  const handleGoogle = async () => {
    await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: `${location.origin}/auth/callback` } })
  }

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Top hero */}
      <div
        className="w-full flex flex-col items-center py-10 rounded-b-[40px]"
        style={{ background: 'linear-gradient(160deg,#1B5E20,#2D7A3A)' }}
      >
        <Image src="/Ninja Greetings.png" alt="ninja" width={130} height={130} className="object-contain drop-shadow-xl" />
        <h2 className="text-white text-2xl font-black mt-3">স্বাগতম!</h2>
        <p className="text-white/60 text-sm">তোমার শেখার যাত্রা চালিয়ে যাও</p>
      </div>

      <div className="flex-1 px-6 pt-7 pb-10">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-600 text-sm px-4 py-3 rounded-xl mb-4 font-bold">
            {error}
          </div>
        )}

        {/* Google */}
        <button onClick={handleGoogle}
          className="w-full flex items-center justify-center gap-3 py-3.5 border-2 border-ninja-border rounded-2xl font-bold text-sm text-ninja-text mb-5 active:scale-95 transition-transform">
          <svg viewBox="0 0 24 24" className="w-5 h-5">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
          </svg>
          Google দিয়ে চালিয়ে যাও
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="flex-1 h-px bg-ninja-border" />
          <span className="text-ninja-muted text-xs font-semibold">অথবা</span>
          <div className="flex-1 h-px bg-ninja-border" />
        </div>

        <div className="space-y-3 mb-2">
          <div className="flex items-center border-2 border-ninja-border rounded-2xl px-4 gap-3 focus-within:border-brand-primary transition-colors">
            <Mail size={16} className="text-ninja-muted flex-shrink-0" />
            <input
              type="email" placeholder="ইমেইল"
              value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
              className="flex-1 py-4 text-sm font-semibold text-ninja-text outline-none placeholder:text-ninja-muted bg-transparent"
            />
          </div>
          <div className="flex items-center border-2 border-ninja-border rounded-2xl px-4 gap-3 focus-within:border-brand-primary transition-colors">
            <Lock size={16} className="text-ninja-muted flex-shrink-0" />
            <input
              type={showPw ? 'text' : 'password'} placeholder="পাসওয়ার্ড"
              value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
              className="flex-1 py-4 text-sm font-semibold text-ninja-text outline-none placeholder:text-ninja-muted bg-transparent"
            />
            <button onClick={() => setShowPw(!showPw)} className="text-ninja-muted">
              {showPw ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
        </div>

        <p className="text-right text-brand-primary text-sm font-bold mb-6">পাসওয়ার্ড ভুলে গেছো?</p>

        <button
          onClick={handleLogin}
          disabled={loading}
          className="w-full py-4 rounded-2xl font-black text-white text-base active:scale-95 transition-transform disabled:opacity-60"
          style={{ background: 'linear-gradient(135deg,#2D7A3A,#3DAE4F)' }}
        >
          {loading ? 'লগইন হচ্ছে...' : 'লগইন'}
        </button>

        <p className="text-center mt-5 text-sm text-ninja-muted">
          অ্যাকাউন্ট নেই?{' '}
          <Link href="/signup" className="text-brand-primary font-black">সাইন আপ করো</Link>
        </p>
      </div>
    </div>
  )
}
